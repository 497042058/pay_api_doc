#   目录
[TOC]

#   配置信息
##  请求路径（TOMCAT）
    http://localhost:8080/pay_demo/index.jsp
##  配置信息:
    src/main/resources/jdbc.properties
    src/main/resources/pay.properties
##  jar-download-url
    http://mvnrepository.com/

##  业务路径
>   交易url:  http://localhost:8080/pay_demo/index.jsp

>   商户入件path:   src/test/java/com/pay/test/TestCustomerReport.java

>   对账单下载path:  src/test/java/com/pay/test/TestJsonDownloadBill.java

>   异步通知:   src/main/java/com/pay/controller/WechatNotify.java

#   源码目录结构
├─src
│  └─main
│      └─java
│         └─com
│            └─pay
│               ├─common                    公共类
│               ├─controller                action
│                     ├─QRCodePayController 生成二维码Demo
│                     ├─WechatController    支付Demo
│                     └─WechatNotify        异步通知Demo
│               ├─dao                       接口
│               ├─entity                    实体
│               ├─exception                 自定义异常
│               ├─service                   服务层
│               ├─vo                        对外实体
│
│      └─resources
│            ├─mapping
│            ├─* 配置文件
│ 
│      └─webapp
│            ├─* 页面文件
│  └─test
│      └─java
│         └─com
│            └─pay
│                └─test
│                   └─TestCustomerReport    商户进件Demo
│                   └─TestJsonDownloadBill  对账单下砸Demo
│                   └─TestMyBatis           框架测试
│      └─resources
│            ├─* 配置文件
