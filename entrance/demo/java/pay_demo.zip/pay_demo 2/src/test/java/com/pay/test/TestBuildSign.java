package com.pay.test;

import com.pay.common.util.MD5Util;

public class TestBuildSign {

    public static void main(String[] args) {
        String str = "";
        String sign = MD5Util.MD5Encode(str).toUpperCase();
        System.out.println("sign==>" + sign);
    }

}
