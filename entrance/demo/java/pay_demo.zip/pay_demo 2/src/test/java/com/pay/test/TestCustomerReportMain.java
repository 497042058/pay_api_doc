package com.pay.test;

import com.pay.common.constant.Constant;
import com.pay.common.util.HttpClientMultiThreadJSONUtil;
import com.pay.common.util.JSONUtil;
import com.pay.common.util.StringUtil;
import com.pay.vo.customer.CustomerReportRequest;
import com.pay.vo.customer.CustomerReportResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class TestCustomerReportMain {
    private static Logger log = LoggerFactory.getLogger(TestCustomerReportMain.class);

    /**
     * 商户进件
     */
    public static void main(String[] args) {
        String agentNum = "A147860093307610145";
        String apiKey = "2e01317bb92a458280ca2ec3a466ceba";
        String appId = "appId";
        String customerType = "ENTERPRISE";
        String businessType = "204";
        String businessName = "businessName";
        String legalName = "legalName";
        String legalId = "512501197203035172";
        String contact = "contact";
        String contactPhone = "13811172449";
        String contactEmail = "4234234@qq.com";
        String customerName = "customerName";
        String address = "address";
        String provinceName = "provinceName";
        String cityName = "cityName ";
        String districtName = "districtName";
        String licenseNo = "licenseNo";
        String rate = "0.6";
        String t0Status = "N";
        String settleRate = "0";
        String fixedFee = "2";
        String isCapped = "N";
        String settleMode = "T1_AUTO";
        String upperFee = "28";
        String accountType = "COMPANY";
        String accountName = "accountName";
        String bankCard = "1234567890123456777";
        String bankName = "bankName";
        String province = "province";
        String city = "city";
        String bankAddress = "bankAddress";
        String alliedBankNo = "123456789012";
        String customerNum = "C149083959281110760";
        String doorHeadImage = "doorHeadImage.jpg";
        String licenseImage = "licenseImage.jpg";
        String rightBankCard = "rightBankCard.jpg";
        String reservedID = "reservedID.jpg";
        String IDWithHand = "IDWithHand.jpg";
        String accountLicence = "accountLicence.jpg";
        String payChannel = "WECHAT_OFFLINE";
        String outMchId = "";
        String serviceType = "CUSTOMER_ENTER";
        String servicePhone = "010-3333333";
        String rightID = "rightId.jpg";

        CustomerReportRequest customerReportRequest = new CustomerReportRequest(apiKey, serviceType, agentNum, outMchId, appId, customerType,
                businessType, businessName, legalId, legalName, contact, contactPhone,
                contactEmail, servicePhone, customerName, address, provinceName, cityName,
                districtName, licenseNo, payChannel, rate, t0Status, settleRate,
                fixedFee, isCapped, settleMode, upperFee, accountType, accountName,
                bankCard, bankName, province, city, bankAddress, alliedBankNo,
                rightID, reservedID, IDWithHand, rightBankCard, licenseImage, doorHeadImage,
                accountLicence, log);

        CustomerReportResponse response = new CustomerReportResponse();
        Map<String, Object> params = customerReportRequest.toMap();
        String parameters = JSONUtil.toJSONString(params);
        String gatewayUrl = Constant.PAY_GATEWAY_URL;
        HttpClientMultiThreadJSONUtil httpclient = new HttpClientMultiThreadJSONUtil(gatewayUrl);
        String respStr = httpclient.sendJsonPost(parameters, log);
        if (StringUtil.isBlank(respStr)) {
            response.setReturn_code(Constant.FAIL);
            response.setReturn_msg("商户进件返回数据为空");
            log.info("商户进件返回数据：{}", respStr);
            return;
        }
        try {
            response = JSONUtil.parseObject(respStr, CustomerReportResponse.class);
        } catch (Exception e) {
            response.setReturn_code(Constant.FAIL);
            response.setReturn_msg("商户进件接口返回数据为空");
            log.info("商户进件接口返回数据：{}", respStr);
            return;
        }
        log.info("商户报备返回结果：{}", JSONUtil.toJSONString(response));

    }


}
