package com.pay.test;

import com.pay.common.util.HttpClientJsonRespFileUtil;
import com.pay.common.util.JSONUtil;
import com.pay.common.util.SignatureUtil;
import com.pay.vo.download.DownloadBillsRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.HashMap;
import java.util.Map;

/**
 * 对账单下载测试Demo
 *
 */


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring.xml", "classpath:spring-mybatis.xml"})
public class TestJsonDownloadBill {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Test
    public void download() {
        // step 1 init paramers
        String serviceType = "CHECK_ORDER";
        String agentNum = "A148453789053010383";
        String key = "26af2bcd5e7b4b289c4aa004a93848a8";
        // Date now = new Date();
        // String orderDate = DateUtil.parseDate(DateUtil.addDays(now, -1),
        // DateUtil.DATE_STYLE_YYYYMMDD);
        String orderDate = "20170424";
        DownloadBillsRequest requst = new DownloadBillsRequest(key, serviceType, agentNum, orderDate, logger);

        // step 2 send post
        String path = "/Users/mymac/Desktop/" + "statement" + orderDate + ".csv";
        String url = "http://101.200.59.129:20030/customer/service";
        try {
            String jsonParamsStr = JSONUtil.toJSONString(requst.toMap());
            HttpClientJsonRespFileUtil httpclient = new HttpClientJsonRespFileUtil(url);
            httpclient.sendJsonPostDownloadFile(jsonParamsStr, path, "UTF-8");
            System.out.println("下载对账单完成。");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("错误信息： " + e);
        }

    }

    @Test
    public void download_statement() {
        // step 1 init paramers
        String serviceType = "CHECK_ORDER";
        String agentNum = "A148453789053010383";
        String key = "26af2bcd5e7b4b289c4aa004a93848a8";
        String orderDate = "20170424";
        Map<String, Object> map = new HashMap<>();
        map.put("serviceType", serviceType);
        map.put("agentNum", agentNum);
        map.put("orderDate", orderDate);
        //sign
        String sign = SignatureUtil.getSign(map, key, logger);
        map.put("sign", sign);
        // step 2 send post
        String path = "/Users/mymac/Desktop/" + "statement_" + orderDate + ".csv";
        String url = "http://101.200.59.129:20030/customer/service";
        try {
            String jsonParamsStr = JSONUtil.toJSONString(map);
            HttpClientJsonRespFileUtil httpclient = new HttpClientJsonRespFileUtil(url);
            httpclient.sendJsonPostDownloadFile(jsonParamsStr, path, "UTF-8");
            System.out.println("下载对账单完成。");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("错误信息： " + e);
        }

    }
}
