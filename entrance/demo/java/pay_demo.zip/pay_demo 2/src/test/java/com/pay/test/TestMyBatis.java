package com.pay.test;

import com.pay.common.util.JSONUtil;
import com.pay.dao.MerchantMapper;
import com.pay.entity.Merchant;
import com.pay.entity.MerchantExample;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring.xml", "classpath:spring-mybatis.xml"})
public class TestMyBatis {
    private static Logger log = LoggerFactory.getLogger(TestMyBatis.class);

    @Resource
    private MerchantMapper merchantMapper;

    @Test
    public void testQueryByUserName() {
        String userName = "zhangsan";
        MerchantExample example = new MerchantExample();
        example.createCriteria().andNameEqualTo(userName);
        List<Merchant> merchants = merchantMapper.selectByExample(example);
        String result = JSONUtil.toJSONString(merchants);
        log.info("merchants: {}", result);
        System.out.println("merchants: " + result);
    }

}
