package com.pay.service.impl;

import com.pay.common.constant.Constant;
import com.pay.common.util.HttpClientMultiThreadJSONUtil;
import com.pay.common.util.JSONUtil;
import com.pay.common.util.StringUtil;
import com.pay.service.IWechatService;
import com.pay.vo.base.WechatRequestBase;
import com.pay.vo.base.WechatResponseBase;
import com.pay.vo.customer.CustomerReportRequest;
import com.pay.vo.customer.CustomerReportResponse;
import com.pay.vo.micro.WechatMicroRequest;
import com.pay.vo.micro.WechatMicroResponse;
import com.pay.vo.orderquery.WechatOrderQueryRequest;
import com.pay.vo.orderquery.WechatOrderQueryResponse;
import com.pay.vo.scan.WechatScannedRequest;
import com.pay.vo.scan.WechatScannedResponse;
import org.slf4j.Logger;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 微信业务实现
 */
@Service
public class WechatServiceImpl implements IWechatService {

    @Override
    public WechatScannedResponse doScanned(WechatScannedRequest scannedRequest, Logger log) {
        // step 1 init param
        WechatScannedResponse scannedResponse = new WechatScannedResponse();
        log.info("请求参数:{}", scannedRequest);
        String gatewayUrl = Constant.PAY_GATEWAY_URL;
        log.info("请求地址: {}", gatewayUrl);

        // step 2 send json post
        String sendPost = sendJsonPost(gatewayUrl, scannedRequest, scannedResponse, log);
        if (StringUtil.isBlank(sendPost)) {
            return scannedResponse;
        }

        //step 3 covert response
        try {
            scannedResponse = JSONUtil.parseObject(sendPost, WechatScannedResponse.class);
        } catch (Exception e) {
            log.info("转换返回数据异常,信息: {}", e);
            scannedResponse.setReturn_code(Constant.FAIL);
            scannedResponse.setReturn_msg("返回参数转换异常");
            return scannedResponse;
        }
        log.info("强转的对象为: {}", scannedResponse);

        //step 4 return
        return scannedResponse;
    }

    @Override
    public WechatMicroResponse doMicro(WechatMicroRequest microRequest, Logger log) {
        // step 1 init param
        WechatMicroResponse microResponse = new WechatMicroResponse();
        log.info("请求参数:{}", microRequest);
        String gatewayUrl = Constant.PAY_GATEWAY_URL;
        log.info("请求地址: {}", gatewayUrl);

        long costTimeStart = System.currentTimeMillis();//start
        // step 2 send json post
        String sendPost = sendJsonPost(gatewayUrl, microRequest, microResponse, log);
        if (StringUtil.isBlank(sendPost)) {
            return microResponse;
        }

        //step 3 covert response
        try {
            microResponse = JSONUtil.parseObject(sendPost, WechatMicroResponse.class);
        } catch (Exception e) {
            log.info("转换返回数据异常,信息: {}", e);
            microResponse.setReturn_code(Constant.FAIL);
            microResponse.setReturn_msg("返回参数转换异常");
            return microResponse;
        }
        log.info("强转的对象为: {}", microResponse);

        //step 4 return
        return microResponse;
    }

    @Override
    public WechatOrderQueryResponse doOrderQuery(WechatOrderQueryRequest orderQueryRequest, Logger log) {
        // step 1 init param
        WechatOrderQueryResponse orderQueryResponse = new WechatOrderQueryResponse();
        log.info("请求参数:{}", orderQueryRequest);

        String gatewayUrl = Constant.PAY_GATEWAY_URL;
        log.info("请求地址: {}", gatewayUrl);

        // step 2 send json post
        String sendPost = sendJsonPost(gatewayUrl, orderQueryRequest, orderQueryResponse, log);
        if (StringUtil.isBlank(sendPost)) {
            return orderQueryResponse;
        }

        //step 3 covert response
        try {
            orderQueryResponse = JSONUtil.parseObject(sendPost, WechatOrderQueryResponse.class);
        } catch (Exception e) {
            log.info("转换返回数据异常,信息: {}", e);
            orderQueryResponse.setReturn_code(Constant.FAIL);
            orderQueryResponse.setReturn_msg("返回参数转换异常");
            return orderQueryResponse;
        }
        log.info("强转的对象为: {}", orderQueryResponse);

        //step 4 return
        return orderQueryResponse;
    }

    /**
     * 商户进件
     *
     * @param customerReportRequest
     * @param log
     * @return
     */
    @Override
    public CustomerReportResponse doCustomerReport(CustomerReportRequest customerReportRequest, Logger log) {
        CustomerReportResponse response = new CustomerReportResponse();
        Map<String, Object> params = customerReportRequest.toMap();
        String parameters = JSONUtil.toJSONString(params);
        String reportUrl = Constant.PAY_CUSTOMER_REPORT_URL;
        HttpClientMultiThreadJSONUtil httpclient = new HttpClientMultiThreadJSONUtil(reportUrl);
        String respStr = httpclient.sendJsonPost(parameters, log);
        if (StringUtil.isBlank(respStr)) {
            response.setReturn_code(Constant.FAIL);
            response.setReturn_msg("商户进件返回数据为空");
            log.info("商户进件返回数据：{}", respStr);
            return response;
        }
        try {
            response = JSONUtil.parseObject(respStr, CustomerReportResponse.class);
        } catch (Exception e) {
            response.setReturn_code(Constant.FAIL);
            response.setReturn_msg("商户进件接口返回数据为空");
            log.info("商户进件接口返回数据：{}", respStr);
        }
        return response;
    }


    /**
     * send json post
     *
     * @param url
     * @param requestBase
     * @param responseBase
     * @param log
     * @return
     */
    String sendJsonPost(String url, WechatRequestBase requestBase, WechatResponseBase responseBase, Logger log) {
        String sendPost = null;
        long costTimeStart = System.currentTimeMillis();//start
        try {
            HttpClientMultiThreadJSONUtil httpclient = new HttpClientMultiThreadJSONUtil(url);
            sendPost = httpclient.sendJsonPost(JSONUtil.toJSONString(requestBase.toMap()), log);
        } catch (Exception e) {
            log.info("请求出错: {}", e);
            responseBase.setReturn_code(Constant.FAIL);
            responseBase.setReturn_msg("请求出错");
        }
        long costTimeEnd = System.currentTimeMillis();//end
        long totalTimeCost = costTimeEnd - costTimeStart;// 总耗时
        log.info("请求总耗时：{}ms", totalTimeCost);
        log.info("返回数据: {}", sendPost);
        return sendPost;
    }
}
