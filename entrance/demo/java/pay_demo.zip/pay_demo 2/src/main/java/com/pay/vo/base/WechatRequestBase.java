package com.pay.vo.base;

import com.pay.vo.AbstractBase;

import java.util.Map;

public abstract class WechatRequestBase extends AbstractBase {

    public abstract Map<String, Object> toMap();

}
