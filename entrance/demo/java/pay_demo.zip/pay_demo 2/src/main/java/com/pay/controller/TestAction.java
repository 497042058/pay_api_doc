package com.pay.controller;

import com.pay.controller.base.BaseAPIActionSupport;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.Map;

@Controller
public class TestAction extends BaseAPIActionSupport {

    @RequestMapping("/testAction")
    @Override
    public Map<String, Object> process() {
        Map<String, Object> result = new HashMap<>();
        log.info("hello!");

        result.put("return_code", "SUCCESS");
        return result;
    }

    @Override
    protected void verifyParameter() {
        return;
    }
}
