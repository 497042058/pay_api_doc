package com.pay.controller.base;

import com.alibaba.fastjson.JSON;
import com.pay.common.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 前端与服务端进行数据交互的接口基础Action，用来提供通用日志输出、参数验证、执行耗时等通用方法，简化开发。<br>
 * 该类是所有Action操作类的入口类，子类必须实现{@link #verifyParameter verifyParameter()}方法。<br>
 * {@link #verifyParameter}方法用来验证参数的合法性<br>
 */
public abstract class BaseAPIActionSupport {
    protected final Logger log = LoggerFactory.getLogger(getClass());

    /**
     * 请求开始时间
     */
    private long startTime;
    /**
     * 请求结束时间
     */
    private long endTime;
    protected HttpServletRequest request;
    protected HttpServletResponse response;
    protected ServletContext application;
    protected HttpSession session;

    public void setServletContext(ServletContext context) {
        this.application = context;
    }

    /**
     * 接口执行入口
     */
    public String execute() {
        // 开始记录日志
        if (allowPrintLog()) {
            start();
        }

        // step1 定义接口返回值
        Map<String, Object> resultMap = null;
        try {
            // step2 验证参数合法性
            verifyParameter();
            // step3 验证签名合法性
            verifySignature();
            // step4 执行业务逻辑操作
            resultMap = process();
        } catch (Exception e) {
            resultMap = new HashMap<String, Object>();
            resultMap.put("return_code", "Failure");
            resultMap.put("return_msg", e.toString());
        }

        // 结束日志记录
        if (allowPrintLog()) {
            end(resultMap);
        }

        // 输出json结果
        // 需要判断是否为JsonP
        String callback = request.getParameter("callback");
        if (StringUtil.isNotBlank(callback)) {
            String resultJson = JSON.toJSONString(resultMap);
//            WebPrintUtil.out(response, callback + "(" + resultJson + ")");
        } else {
//            WebPrintUtil.outjson(response, resultMap);
        }
        return null;
    }

    /**
     * 接口处理开始前打印日志
     */
    private void start() {
        startTime = System.currentTimeMillis();
        // 获得请求参数
        Map<String, String[]> parameterMap = request.getParameterMap();
        Map<String, String> params = parseParam(parameterMap);
        log.info("请求开始[URI:{}, Method:{}, Params:{}]", request.getRequestURI(),
                request.getMethod(), params.toString());
    }

    /**
     * 接口处理结束后打印日志
     */
    private void end(Map<String, Object> resultMap) {
        endTime = System.currentTimeMillis();
        log.info("请求结束[URI:{}, 耗时:{}毫秒, Result:{}]", request.getRequestURI(),
                (endTime - startTime), JSON.toJSONString(resultMap));
    }

    /**
     * 打印日志
     *
     * @return
     */
    protected boolean allowPrintLog() {
        return true;
    }

    /**
     * 是否需要签名验证
     *
     * @return
     */
    protected boolean requiredVerifySign() {
        return false;
    }

    /**
     * 签名验证
     *
     * @return
     */
    private void verifySignature() {
        if (requiredVerifySign() == false) {
            return;
        }
    }

    /**
     * 处理接口的方法，由具体的子类接口处理
     *
     * @return 数据结果集，map中必包含success值，用来显示处理状态
     */
    public abstract Map<String, Object> process();

    /**
     * 验证参数合法性
     *
     * @return
     */
    protected abstract void verifyParameter();

    /**
     * 将参数值的数组转化为字符串
     *
     * @param map
     * @return
     */
    private Map<String, String> parseParam(Map<String, String[]> map) {
        Map<String, String> coverMap = new HashMap<>();
        Set<String> keySet = map.keySet();
        for (Object obj : keySet.toArray()) {
            String paramKey = obj.toString();
            String paramValue = String.valueOf((map.get(obj))[0]);
            coverMap.put(paramKey, paramValue);
        }
        return coverMap;
    }
}