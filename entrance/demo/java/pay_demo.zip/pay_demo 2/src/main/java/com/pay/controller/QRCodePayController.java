package com.pay.controller;

import com.pay.common.constant.Constant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

/**
 * 二维码支付
 *
 */
@Controller
public class QRCodePayController {
    private Logger log = LoggerFactory.getLogger(this.getClass());

    @RequestMapping("/createAYardToPay")
    public String createAYardToPay(HttpServletRequest request) {
        String url = Constant.DOMAIN_NAME + "/choosePayChannel";
        request.setAttribute("url", url);
        return "qrcode/qrcode_entry";
    }

    @RequestMapping("/choosePayChannel")
    public String choosePayChannel(HttpServletRequest request) {
        String head = request.getHeader("User-Agent").toLowerCase();
        log.info("User-Agent===>{}", head);

        String wechatHead = "micromessenger";
        String alipayHead = "alipayclient";
        String result = "";

        if (head.contains(wechatHead)) {
            result = "微信支付";
        } else if (head.contains(alipayHead)) {
            result = "支付宝支付";
        } else {
            result = "暂时只支持微信&支付宝!";
        }
        log.info("User-Agent===>{}", head);
        log.info("支付通道===>{}", result);
        request.setAttribute("result", result);
        return "qrcode/qrcode_result";
    }

}
