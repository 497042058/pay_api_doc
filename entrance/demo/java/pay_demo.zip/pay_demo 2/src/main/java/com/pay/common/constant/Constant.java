package com.pay.common.constant;

import com.pay.common.util.PropertiesUtil;

public class Constant {
    /**
     * 订单号前缀
     */
    public static String ORDER_PREFIX = "ORDER";
    /**
     * 编码格式
     */
    public static String UTF8 = "UTF-8";
    /**
     * MD5
     */
    public static String MD5 = "MD5";
    /**
     * SUCCESS
     */
    public static String SUCCESS = "SUCCESS";
    /**
     * FAIL
     */
    public static String FAIL = "FAIL";
    /**
     * 加密key
     */
    public static String PAY_KEY = PropertiesUtil.getString("pay.key");
    /**
     * 商户号
     */
    public static String PAY_MCH_ID = PropertiesUtil.getString("pay.mch_id");
    /**
     * 请求网关
     */
    public static String PAY_GATEWAY_URL = PropertiesUtil.getString("pay.gateway.url");
    /**
     * 进件
     */
    public static String PAY_CUSTOMER_REPORT_URL = PropertiesUtil.getString("pay.customer.report.url");
    /**
     * 后台回调地址
     */
    public static String PAY_NOTIFY_URL = PropertiesUtil.getString("pay.notify.url");
    /**
     * 前端结果地址
     */
    public static String PAY_CALLBACK_URL = PropertiesUtil.getString("pay.callback.url");
    /**
     * 域名
     */
    public static String DOMAIN_NAME = PropertiesUtil.getString("domain.name");
    /**
     * 请求类型
     */
    public static String SERVICE_TYPE_WECHAT_SCANNED = "WECHAT_SCANNED";//订单查询
    public static String SERVICE_TYPE_WECHAT_MICRO = "WECHAT_MICRO";//刷卡(小额)
    public static String SERVICE_TYPE_WECHAT_WEBPAY = "WECHAT_WEBPAY";//公众号
    public static String SERVICE_TYPE_WECHAT_ORDERQUERY = "WECHAT_ORDERQUERY";//订单查询
    /**
     * 订单类型
     */
    public static String ORDER_TYPE_WECHAT = "WECHAT";//微信
    /**
     * 货币单位
     */
    public static String FEE_TYPE = "CNY";//微信


}
